--- Solved By Sanjay Panchal

--- Database Name -> SQL_CASE_STUDY

--select * from event
--select * from status
--select * from delayreason
--select * from  downreason
--select * from readyreason
--select * from sparereason


select EV.EventID, EV.Duration, EV.[Status Name], SR.Name from
(
select E.EventID, E.Duration, E.StatusCode, E.ReasonCode, S.Name as [Status Name] from Event E
left join Status S
on E.StatusCode=S.StatusCode) EV
left join
(
select 'R' as [Status Code], ReasonCode, Name from ReadyReason
UNION
select 'D1', ReasonCode, Name from DelayReason
UNION
select 'S', ReasonCode, Name from SpareReason
UNION
select 'D2', ReasonCode, Name from DownReason
) SR
on EV.StatusCode=SR.[Status Code]
and EV.ReasonCode=SR.ReasonCode
