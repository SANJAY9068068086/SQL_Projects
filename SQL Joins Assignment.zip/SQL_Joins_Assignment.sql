-- Database Name = Database -> SQL_Joins_Assignment

select * from EmployeeDetails
select * from ProjectDetails

/* Question No. 1 -- Get Employee Name, Project Name order by firstname from "EmployeeDetail" and "ProjectDetail"for those Employee
                     which have assigned project already. */

select ED.FirstName, PD.ProjectName from EmployeeDetails ED
inner join ProjectDetails PD
on ED.EmployeeID=PD.ProjectDetailID
order by ED.FirstName

/* Question No. 2 -- Get Employee Name, Project Name order by firstname from "EmployeeDetail" and "ProjectDetail"for those Employee
                     even they have not assigned project. */

select ED.FirstName, PD.ProjectName from EmployeeDetails ED
left join ProjectDetails PD
on ED.EmployeeID=PD.ProjectDetailID
order by ED.FirstName

/* Question No. 3 -- Get all project name even they have not matching any employeeid, in left table,order by firstname
                     from "EmployeeDetail" and "ProjectDetail". */

select ED.FirstName, PD.ProjectName from EmployeeDetails ED
right join ProjectDetails PD
on ED.EmployeeID=PD.ProjectDetailID
order by ED.FirstName

/*  Question No. 4 --Get Employee Record (Employeename, project name)from both tables ([EmployeeDetail],[ProjectDetail],
                     if no match found in any table then show null. */

select ED.FirstName, PD.ProjectName from EmployeeDetails ED
full join ProjectDetails PD
on ED.EmployeeID=PD.ProjectDetailID
order by ED.FirstName
